# pricebot
## this is a simple chatbot developed in ruby. for now it only double a number when received or square that number. for example if you give double n it return n + n, but if you give square n; it return n * n.
## in future i want to extend its features to negotiate prices of different products with customer. it can be used in online stores and ecommerce. 

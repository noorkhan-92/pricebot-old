# lita-doubler

[![Build Status](https://travis-ci.org/noorkhan-92/lita-doubler.png?branch=master)](https://travis-ci.org/noorkhan-92/lita-doubler)
[![Coverage Status](https://coveralls.io/repos/noorkhan-92/lita-doubler/badge.png)](https://coveralls.io/r/noorkhan-92/lita-doubler)

TODO: Add a description of the plugin.

## Installation

Add lita-doubler to your Lita instance's Gemfile:

``` ruby
gem "lita-doubler"
```

## Configuration

TODO: Describe any configuration attributes the plugin exposes.

## Usage

TODO: Describe the plugin's features and how to use them.
